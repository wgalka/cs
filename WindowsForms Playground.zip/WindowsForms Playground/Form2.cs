﻿namespace WindowsForms_Playground {
    public partial class Form2 : Form {
        public Form2() {
            InitializeComponent();

            Text = "Windows Forms – Wszystkie Kontrolki";
            Size = new Size(1000, 800);
            AutoScroll = true;

            var y = 10;

            Controls.Add(new Label() { Text = "Label", Location = new Point(10, y) });
            y += 30;

            Controls.Add(new TextBox() { Location = new Point(10, y), Width = 200 });
            y += 30;

            Controls.Add(new Button() { Text = "Button", Location = new Point(10, y) });
            y += 30;

            Controls.Add(new CheckBox() { Text = "CheckBox", Location = new Point(10, y) });
            y += 30;

            Controls.Add(new RadioButton() { Text = "RadioButton", Location = new Point(10, y) });
            y += 30;

            Controls.Add(new LinkLabel() { Text = "LinkLabel", Location = new Point(10, y) });
            y += 30;

            Controls.Add(new RichTextBox() { Location = new Point(10, y), Width = 200, Height = 60 });
            y += 70;

            Controls.Add(new MaskedTextBox() { Location = new Point(10, y), Mask = "(000) 000-0000" });
            y += 30;

            Controls.Add(new NumericUpDown() { Location = new Point(10, y), Maximum = 100 });
            y += 30;

            Controls.Add(new DomainUpDown() { Location = new Point(10, y), Items = { "Opcja 1", "Opcja 2" } });
            y += 30;

            Controls.Add(new ComboBox() { Location = new Point(10, y), Items = { "A", "B", "C" } });
            y += 30;

            Controls.Add(new ListBox() { Location = new Point(10, y), Items = { "Jeden", "Dwa" }, Height = 40 });
            y += 50;

            Controls.Add(new CheckedListBox() { Location = new Point(10, y), Items = { "Opcja A", "Opcja B" }, Height = 40 });
            y += 50;

            Controls.Add(new TrackBar() { Location = new Point(10, y), Width = 200 });
            y += 50;

            Controls.Add(new ProgressBar() { Location = new Point(10, y), Value = 50, Width = 200 });
            y += 30;

            Controls.Add(new DateTimePicker() { Location = new Point(10, y) });
            y += 30;

            Controls.Add(new MonthCalendar() { Location = new Point(10, y) });
            y += 170;

            TreeView tree = new TreeView() { Location = new Point(250, 10), Width = 150 };
            tree.Nodes.Add("Node 1").Nodes.Add("Child 1");
            Controls.Add(tree);

            ListView list = new ListView() { Location = new Point(250, 150), Width = 200, Height = 100, View = View.Details };
            list.Columns.Add("Kolumna 1", 100);
            list.Items.Add(new ListViewItem("Wiersz 1"));
            Controls.Add(list);

            Controls.Add(new PictureBox() {
                Location = new Point(250, 270),
                Size = new Size(100, 100),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.LightBlue
            });

            ToolTip tooltip = new ToolTip();
            var tooltipBtn = new Button() { Text = "Z podpowiedzią", Location = new Point(250, 380) };
            tooltip.SetToolTip(tooltipBtn, "To jest podpowiedź!");
            Controls.Add(tooltipBtn);

            ErrorProvider error = new ErrorProvider();
            var errorBox = new TextBox() { Location = new Point(250, 420) };
            error.SetError(errorBox, "To pole jest wymagane");
            Controls.Add(errorBox);

            FlowLayoutPanel flow = new FlowLayoutPanel() { Location = new Point(500, 10), Size = new Size(200, 100), BorderStyle = BorderStyle.FixedSingle };
            flow.Controls.Add(new Label() { Text = "FlowPanel" });
            flow.Controls.Add(new Button() { Text = "Btn" });
            Controls.Add(flow);

            TableLayoutPanel table = new TableLayoutPanel() { Location = new Point(500, 120), ColumnCount = 2, RowCount = 2, Width = 200 };
            table.Controls.Add(new Label() { Text = "Imię:" }, 0, 0);
            table.Controls.Add(new TextBox(), 1, 0);
            table.Controls.Add(new Label() { Text = "Nazwisko:" }, 0, 1);
            table.Controls.Add(new TextBox(), 1, 1);
            Controls.Add(table);

            SplitContainer split = new SplitContainer() { Location = new Point(500, 200), Size = new Size(300, 100) };
            split.Panel1.Controls.Add(new Label() { Text = "Lewa" });
            split.Panel2.Controls.Add(new Label() { Text = "Prawa" });
            Controls.Add(split);

            GroupBox group = new GroupBox() { Location = new Point(500, 310), Size = new Size(200, 80), Text = "Grupa" };
            group.Controls.Add(new CheckBox() { Text = "Zgoda", Location = new Point(10, 20) });
            Controls.Add(group);

            TabControl tabs = new TabControl() { Location = new Point(500, 400), Size = new Size(200, 100) };
            tabs.TabPages.Add("Zakładka 1");
            tabs.TabPages.Add("Zakładka 2");
            Controls.Add(tabs);

            NotifyIcon notify = new NotifyIcon() {
                Icon = SystemIcons.Information,
                Visible = true,
                Text = "Demo NotifyIcon"
            };
        }
    }
}
