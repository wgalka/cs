﻿namespace WindowsForms_Playground.kontrolki {
    public partial class LabelsFields : Form {
        public LabelsFields() {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e) {

        }

        private void textBox1_TextChanged(object sender, EventArgs e) {

        }

        private void label3_Click(object sender, EventArgs e) {

        }
    }
}
